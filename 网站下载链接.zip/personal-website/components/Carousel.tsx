'use client'

import Image from 'next/image'

export default function Carousel() {
  return (
    <div className="relative h-screen w-full overflow-hidden">
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E6%8A%8A%E4%B8%8B%E9%9D%A2%E5%9B%BE%E7%89%87%E4%BD%9C%E4%B8%BA%E6%AC%A2%E8%BF%8E%E6%9D%A5%E5%88%B0agent%20designer%20%E5%8D%83%E9%80%90%E7%9A%84%E4%B8%AA%E4%BA%BA%E7%BD%91%E7%AB%99%E5%B0%81%E9%9D%A2%E8%BF%99%E5%BC%A0%E6%B5%B7%E6%8A%A5%E5%B1%95%E7%8E%B0%E4%BA%86%E4%B8%80%E7%A7%8D%E7%A5%9E%E7%A7%98%E8%80%8C%E6%A2%A6%E5%B9%BB%E7%9A%84%E9%A3%8E%E6%A0%BC%EF%BC%8C%E8%83%8C%E6%99%AF%E8%AE%BE%E5%AE%9A%E5%9C%A8%E4%B8%80%E4%B8%AA%E6%9C%AA%E6%9D%A5%E6%88%96%E5%B9%BB%E6%83%B3%E4%B8%96%E7%95%8C%E4%B8%AD%E3%80%82%E7%94%BB%E9%9D%A2%E4%B8%AD%E5%BF%83%E6%98%AF%E4%B8%80%E4%B8%AA%E5%B7%A8%E5%A4%A7%E7%9A%84%E3%80%81%E7%94%B1%E7%81%AF%E5%85%89%E6%9E%84%E6%88%90%E7%9A%84%E5%87%A0%E4%BD%95%E5%9B%BE%E6%A1%88%EF%BC%8C%E7%B1%BB%E4%BC%BC%E4%BA%8E%E4%B8%80%E4%B8%AA%E8%BF%B7%E5%AE%AB%E6%88%96%E7%94%B5...-Is80bIxxJ22hOybZEheE2HWxmyCgJ6.jpeg"
        alt="Hero Background"
        layout="fill"
        objectFit="cover"
        priority
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50" />
      <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 text-center">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 text-glow hover-scroll">
          欢迎来到 Agent designer——千逐的个人网站
        </h1>
      </div>
    </div>
  )
}

