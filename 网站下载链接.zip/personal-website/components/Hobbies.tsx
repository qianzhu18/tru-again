import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const hobbies = [
  {
    id: 1,
    title: '羽毛球爱好者',
    description: '热爱羽毛球运动，经常参与比赛和训练'
  },
  {
    id: 2,
    title: '足球深度爱好者',
    description: '热衷于足球运动，关注各大赛事'
  },
  {
    id: 3,
    title: '动漫学者',
    description: '最喜欢的动漫是进击的巨人和碧蓝之海'
  },
  {
    id: 4,
    title: '科技圈爱好者',
    description: '关注最新科技动态，热衷于体验新技术'
  }
]

export default function Hobbies() {
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center text-glow">我的兴趣爱好</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {hobbies.map((hobby) => (
            <Card key={hobby.id} className="card-hover bg-opacity-10 bg-blue-900 border-blue-500/20">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-blue-400">{hobby.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">{hobby.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

